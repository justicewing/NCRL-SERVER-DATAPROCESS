#ifndef TASKSCH_
#define TASKSCH_

void TaskScheduler_tx(void *arg);
void TaskScheduler_rx(void *arg);
void Tx_buff(void *arg);
void Rx_buff(void *arg);

#endif
