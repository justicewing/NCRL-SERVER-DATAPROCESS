#ifndef CALPILOT_
#define CALPILOT_
void CalPilotSymb(int LayerNum, int CarrierNum, int PilotSymb_N, int User_idx, int inter_freq, lapack_complex_float *PilotSymb);
#endif
